import base64
import datetime
import json
import logging
import os
import socket
import sys
import time
import uuid
import yaml

import zmq

class CCU:
    """This is the main library for working with CCU queues and processes.
       Read README-Samples documentation to see sample code which uses this library.
       Read README-Integration documenation to see how to use this library in your code.
       
       You will usually need to imports to use this library:
       import zmq            # Put in third party library list per PEP-8
       from ccu import CCU   # Put in local library list per PEP-8
       print(CCU.__version__)
       
       Design Principals:
         * Convention Over Configuration: Only use configuration files for things which 
           really can change.  (And right now, there are none, but I expect a few in the
           future.)  Otherwise, hardcoded data is prefered.  That way everone knows where
           to look for things, and you don't have a two step process (look in config, then
           look in real location) to find things.
         * Don't Hide/Encapsulate/Wrap Data Structures: Expose the actual data structures
           used to the programmer.  Do not wrap them or hide them in any way.  Programers
           need to understand the underlying data structures to use the library.
       
       There are only two complexities in using this library:
         1. It internally creates exactly one zmq context for your program.  It does
            this when you call CCU.socket for the first time.  If this causes you 
            problems, tell me, and I'll make this context visible and manageable.
         2. Use the right recv function: recv_block if you want to block, which is the
            most common, I think.  Use recv if you don't want to block and want a None
            if there are no messages.  Use recv_throw if you don't want to block and
            want an exception (zmq.AGAIN) thrown if there are no messages waiting.
    """
        
    queues = {
        "ACTION": { "PUB": 11880, "SUB": 12880 },
        "AUDIO_ENV": { "PUB": 11881, "SUB": 12881 },
        "AUDIO_SELF": { "PUB": 11882, "SUB": 12882 },
        "EYE": { "PUB": 11883, "SUB": 12883 },
        "GESTURE": { "PUB": 11884, "SUB": 12884 },
        "HAND": { "PUB": 11885, "SUB": 12885 },
        "IMU": { "PUB": 11886, "SUB": 12886 },
        #MIC1 = -1
        #MIC2 = -2
        #MIC3 = -3
        #MIC4 = -4
        #MIC5 = -5        
        "RESULT": { "PUB": 11887, "SUB": 12887 }, 
        #VIDEO_IRSHORT = -6
        #VIDEO_BW_FRONT1 = -7
        #VIDEO_BW_FRONT2 = -8
        #VIDEO_BW_LEFT = -9
        #VIDEO_BW_RIGHT = -10        
        "VIDEO_MAIN": { "PUB": 11888, "SUB": 12888 },
        "LONGTHROW_DEPTH": { "PUB": 11889, "SUB": 12889 },
        "AUDIO_TTS": { "PUB": 11890, "SUB": 12890 },
        "CONTROL": { "PUB": 11891, "SUB": 12891 },
        "PROCESSED_AUDIO": { "PUB": 11892, "SUB": 12892 },
        "PROCESSED_VIDEO": { "PUB": 11893, "SUB": 12893 },
    }    
             
    __version__ = "0.8" 
    config_dict = {}
    configured = False
    context = None
    debug = False
    host_ip = None
    config_file_path = None
    container_id = None
    """The directory were persistent files should be written by the analytic.
       These are files that might be used after the analytic has finished running:
       log files and other files used for troubleshooting (for example).
       In a containerized analytic, this will be /sandbox/<container_id>_log.
       On a host, it will be ../sandbox/<python program name>_log.       
    """
    log_dir_name = None
    sandbox_dir_name = None
    """The directory were temporary files should be written by the analytic.
       In a containerized analytic, this will be /sandbox/<container_id>_temp.
       On a host, it will be ../sandbox/<python program name>_temp.
    """
    temp_dir_name = None

    
    @classmethod
    def config(cls):
        """Reads the standard CCU config file (ccu-config.yaml) and returns 
           it as a dictionary.
           Exceptions are passed upwards, untouched.
        """
        cls.configured = True
        # For errors that we get before we know enough to do the real basicConfig
        # Will be over written by the real basicConfig later on.
        logging.basicConfig(datefmt='%Y-%m-%d %I:%M:%S',
                            format='%(asctime)s %(levelname)s %(message)s',
                            level=logging.INFO)        
        ccu_sandbox = os.environ.get('CCU_SANDBOX')
        ccu_container = os.environ.get('CCU_CONTAINER')
        cls.container_id = os.environ.get('HOSTNAME')
        # for Windows:
        if cls.container_id is None:
            cls.container_id = os.environ.get('COMPUTERNAME')
        if cls.container_id is None:
            if os.path.exists('/etc/hostname'):
                with open('/etc/hostname') as file:            
                    cls.container_id = file.readline().strip()
        if cls.container_id is None:   
            logging.error(f'Neither HOSTNAME nor COMPUTERNAME is set and could not '+
                          'read /etc/hostname, either.')             
            cls.container_id = 'noname'
        
        if ccu_sandbox is None and ccu_container is None:
            # Normally, we dont configure logging until later, but if we get this error
            # we must.  This is the only error were the CCU library exists, because if 
            # there is no config file (and no sandbox) there is truely nothing we can
            # do.
 
            logging.error(f'Neither CCU_SANDBOX nor CCU_CONTAINER is set and one of '+
                          'them must be set. If running on a host machine CCU_SANDBOX '+
                          'must be set and in a container, CCU_CONTAINER.  CCU is '+
                          'exiting.')            
            sys.exit(1)
        
        # This is pre-configuration when we are running directory on the host
        # computer.
        if ccu_sandbox is not None:
            cls.sandbox_dir_name = ccu_sandbox
            program_name = sys.argv[0]
            # container_id is used for logging so if we are running as processes on the
            # host, then each program name becomes as pseudo container_id to keep their
            # logs seperate.
            if program_name.endswith('.py'):
                cls.container_id = program_name[:-3]
            else:
                cls.container_id = program_name            
                    
        # This is pre-configuration when we are running on a container.
        if ccu_container is not None:
            cls.sandbox_dir_name = os.path.join(os.sep, 'sandbox')
            # Old code.  We now get this data from $HOSTNAME/$COMPUTERNAME above
            # TODO: remove in 0.8 or later.
            # try:
            #    if os.path.exists('/proc/self/cgroup'):
            #        with open("/proc/self/cgroup") as file:            
            #            for line in file.readlines():
            #                if 'docker' in line and 'name=' in line:
            #                    parts = line.split('/')
            #                    cls.container_id = part[2][:12]
            #except:
            #    cls.container_id = os.path.join(os.sep, 'sandbox')
        cls.temp_dir_name = os.path.join(cls.sandbox_dir_name, cls.container_id + '_temp')
        cls.log_dir_name = os.path.join(cls.sandbox_dir_name, cls.container_id + '_log') 
        os.makedirs(cls.temp_dir_name, exist_ok=True)
        os.makedirs(cls.log_dir_name, exist_ok=True)
        
        # This is the initialization done on both places (host and containers)
        # based on the configuration file.
        cls.config_file_path = os.path.join(cls.sandbox_dir_name, 'ccu-config.yaml')
        if os.path.exists(cls.config_file_path):
            with open(cls.config_file_path, 'r') as stream:
                cls.config_dict = yaml.safe_load(stream)
        if 'host_ip' in cls.config_dict:
            cls.host_ip = cls.config_dict['host_ip']
        else:
            # Previously: socket.gethostbyname(socket.gethostname())
            cls.host_ip = "127.0.0.1" 
        if 'debug' in cls.config_dict:
            cls.debug = cls.config_dict['debug']
            logging.basicConfig(filename=os.path.join(cls.log_dir_name, 'ccu.log'),
                                datefmt='%Y-%m-%d %I:%M:%S',
                                format='%(asctime)s %(levelname)s %(message)s',
                                level=logging.DEBUG) 
            logging.info(f'CCU started in debugging mode.  Level is DEBUG.  IP is {cls.host_ip}.')
        else:
            logging.basicConfig(filename=os.path.join(cls.log_dir_name, 'ccu.log'),
                                datefmt='%Y-%m-%d %I:%M:%S',
                                format='%(asctime)s %(levelname)s %(message)s',
                                level=logging.INFO) 
            logging.info(f'CCU started in non-debugging mode.  IP is {cls.host_ip}.')            
        return cls.config_dict  
    
    @classmethod
    def base_message(cls, atype='minimal'):
        """Returns a dictionary which is the minimal CCU message.  It containes
           three fields: type, uuid, and datatime.
           Users should build real messages on top of this function, by calling it
           first, and then adding more fields, something like this:
           message = CCU.base_message('message-type')
           message['data'] = 'more data'
           message['count'] = 5
           message['llr'] = 3.2345
           ... and so on ...
           Message types, the argument to base_message, should be in "rotisserie
           format" (ie. words seperated by dashes).
        """
        message = {}
        message['type'] = atype
        message['uuid'] = cls.uuid()
        message['datetime'] = cls.now()
        return message
        
    @classmethod
    def base64string_to_binary(cls, string_content):
        """Converts a base 64 string into binary data.
           This function should be used to convert a field in a message
           to binary data.
           For example:
           image = CCU.base64string_to_binary(message['image'])
        """
        return base64.b64decode(string_content)

    @classmethod
    def binary_to_base64string(cls, binary_content):
        """Converts binary data into a base64 encoded string.
           This function should be used to convert binary data into a
           string to put in a message.
           For example:
           # image contains binary data, for example, from reading a file
           message['image'] = CCU.binary_to_base64string(image)
        """
        return base64.b64encode(binary_content).decode('utf-8')

    @classmethod
    def setDebug(cls, debug=True):
        """Sets the debugging flag in the CCU library."""
        cls.debug = debug
        
    @classmethod
    def fmt_json(cls, data):
        """Formats a dictionary as json and as a string."""
        return json.dumps(data, indent=4, sort_keys=True)
    
    @classmethod
    def now(cls):
        """Return the current time in the CCU standardized time format.
           Please use this form all logging and datetimes in messages:
           YYYY-MM-DD HH:MM:SS.PPPPPP   (24 hour clock)
           2022-04-13 18:32:13.010763
        """
        return str(datetime.datetime.utcnow())

    @classmethod
    def recv(cls, socket):
        """Checks for a message on a queue.
           Returns None if one is not there.
           The message is a Python dictionary with string keys and only  
           values of integers, floats, strings, and binary data which are 
           strings in base64, lists of these values or dictionaries of 
           these values.           
        """        
        try:
            values = socket.recv_multipart(flags=zmq.NOBLOCK)
            message = json.loads(values[0].decode('utf-8'))
            return message
        except zmq.Again:
            return None
    
    @classmethod
    def recv_throw(cls, socket): 
        """Checks for a message on a queue.
           Throws an exception (zmq.Again) if one is not there.
           The message is a Python dictionary with string keys and only  
           values of integers, floats, strings, and binary data which are 
           strings in base64, lists of these values or dictionaries of 
           these values. 
        """       
        values = socket.recv_multipart(flags=zmq.NOBLOCK)
        message = json.loads(values[0].decode('utf-8'))
        return message 
    
    @classmethod
    def recv_block(cls, socket):
        """Waits for a message on a queue."""      
        values = socket.recv_multipart()
        message = json.loads(values[0].decode('utf-8'))
        return message

    @classmethod
    def send(cls, socket, data):
        """Send a message on the socket (that is, queue) given.  
           The message is a Python dictionary with string keys and only  
           values of integers, floats, strings, and binary data which are 
           strings in base64, lists of these values or dictionaries of 
           these values. 
        """
        message = json.dumps(data, indent=2).encode('utf-8')
        if 'type' in data:
            topic = data['type'].encode('utf-8')
        else:
            topic = b''
        # JCL socket.send_multipart([topic, message])
        socket.send_multipart([message])
    
    @classmethod
    def socket(cls, queue, direction):
        """Create a socket (queue).  The first argument is a CCU queue from the 
           CCU.Queue enum.  The second argument is a zmq type (either PUB or SUB).
           Returns the socket for future sending or recieving.
        """
        if not cls.configured:
            cls.config()         
        if direction != zmq.SUB and direction != zmq.PUB:
            raise Exception('The direction must be either zmq.SUB or zmq.PUB.  Nothing else is supported.')
        if 'SUB' not in queue or 'PUB' not in queue:
            raise Exception('This is not a queue.')
        
        if cls.context is None:
            cls.context = zmq.Context()
            
        socket = CCU.context.socket(direction)
        if direction == zmq.SUB:
            if cls.debug:
                logging.debug(f'CCU connecting to tcp://{cls.host_ip}:{queue["SUB"]}') 
            socket.setsockopt(zmq.SUBSCRIBE, b'')
            socket.connect(f'tcp://{cls.host_ip}:{queue["SUB"]}')
            # Mikhail: socket.connect(f'tcp://{CCU.ip_address}:{queue.value}')
        elif direction == zmq.PUB:
            if cls.debug:
                logging.debug(f'CCU connecting to tcp://{cls.host_ip}:{queue["PUB"]}')            
            socket.connect(f'tcp://{cls.host_ip}:{queue["PUB"]}')
            ##socket.bind(f'tcp://*:{queue.value}')
            ###socket.bind(f'tcp://host.docker.internal:{queue.value}')
            # This is absolutely required by ZMQ and I don't know why.
            time.sleep(1)
        return socket
    
    @classmethod
    def uuid(cls):
        """Returns a string which is a Unique Universal ID.
           Please use this function for all unique identifiers in the CCU
           system, and especially for message fields.
        """
        return str(uuid.uuid4())

if __name__ == '__main__':
    print(f'Testing basic functionality of ccu.py, but not send/recv.')
    CCU.config()
    print(f'debugging? {CCU.debug}')
    print(f'Containerized? {os.environ.get("CCU_CONTAINER")!=None}')
    print(f'Container id: {CCU.container_id}')
    print(f'Temp directory: {CCU.temp_dir_name}')
    print(f'Log directory: {CCU.log_dir_name}')
    print(f'Time now is {CCU.now()}')
    print(f'base_message is {CCU.fmt_json(CCU.base_message())}')
    print(f'base_message("example") is {CCU.fmt_json(CCU.base_message("example"))}')
    print(f'config is {CCU.fmt_json(CCU.config())}')
    print(f'UUIDs are {CCU.uuid()} {CCU.uuid()}')
    print(f'Time now is {CCU.now()}')